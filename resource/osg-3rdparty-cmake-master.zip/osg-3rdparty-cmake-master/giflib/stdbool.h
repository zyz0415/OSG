#ifndef _STDBOOL_H
#define _STDBOOL_H    1

#ifndef __cplusplus
typedef int bool;
#define false 0
#define true 1
#endif

#endif